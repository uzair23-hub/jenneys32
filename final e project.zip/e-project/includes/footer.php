<!-- Sticky Responsive Footer -->
<style>
  body {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  }
  .site-footer {
    margin-top: auto;
    width: 100%;
    background-color: #473068 ;
    color: #fff;
    text-align: center;
    padding: 1.5rem 2rem;
    box-shadow: 0 4px 24px rgba(233, 30, 99, 0.08);
    position: relative;
    left: 0;
    bottom: 0;
  }
  @media (max-width: 600px) {
    .site-footer {
      padding: 1rem;
      font-size: 0.95rem;
    }
  }
</style>
<footer class="site-footer">
  <div style="font-family: 'Poppins', sans-serif; font-size: 1.1rem;">
    &copy; <?= date("Y"); ?> Jenny's Cosmetics & Jewelry. All Rights Reserved.
  </div>
  <div style="margin-top: 0.5rem; font-size: 0.95rem; color: #fff;">
    Premium cosmetics and imitation jewelry delivered to your doorstep
  </div>
  <div class="mb-3">
    <a href="https://www.facebook.com" target="_blank" class="text-light me-3 fs-5"><i class="bi bi-facebook"></i></a>
    <a href="https://www.instagram.com" target="_blank" class="text-light me-3 fs-5"><i class="bi bi-instagram"></i></a>
    <a href="https://www.twitter.com" target="_blank" class="text-light me-3 fs-5"><i class="bi bi-twitter"></i></a>
    <a href="https://www.whatsapp.com" target="_blank" class="text-light fs-5"><i class="bi bi-whatsapp"></i></a>
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
