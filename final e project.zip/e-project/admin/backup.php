<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Backup</title>
    <style>
        /* Google Font */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');

        /* Basic Reset */
        

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #f8bbd0;
        }

        /* Card Container */
        .card {
            margin: auto;
            max-width: 95vw;
            width: 400px;
            background: #fff;
            padding: 40px 50px;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
            text-align: center;
            animation: fadeIn 1s ease-in-out;
        }

        /* Heading */
        .card h1 {
            
            color: #333;
            margin-bottom: 10px;
        }

        /* Description */
        .card p {
            color: #555;
            font-size: 14px;
            margin-bottom: 25px;
        }

        /* Button Styling */
        .btn {
            display: inline-block;
            padding: 12px 25px;
            background-color: #090909ff;
            color: white;
            font-size: 16px;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }

        .btn:hover {
            background-color: #555;
            transform: scale(1.05);
        }

        /* Backup Icon Animation */
        .icon {
            font-size: 50px;
            margin-bottom: 15px;
            color: #28a745;
            animation: bounce 1.5s infinite;
        }

        /* Animations */
        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(-20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        @media (max-width: 600px) {
            .card {
                width: 100%;
                padding: 20px 10px;
                border-radius: 12px;
            }
            .card h1 {
                font-size: 20px;
            }
            .btn {
                font-size: 14px;
                padding: 10px 18px;
            }
        }
    </style>
</head>
<?php include("includes/admin_header.php"); ?>
<body>

    <div class="card">
        <div class="icon">📦</div>
        <h1>Database Backup</h1>
        <p>Click the button below to create a secure backup of your database.</p>
        <form action="backup_database.php" method="post">
            <button class="btn" type="submit">Backup Now</button>
        </form>
    </div>
<?php include("includes/admin_footer.php"); ?>
</body>
</html>
