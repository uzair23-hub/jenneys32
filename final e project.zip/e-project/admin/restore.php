<?php
session_start();
include("../includes/db.php");

// Restrict access to admin only
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$message = "";

// Restore process
if (isset($_POST['restore'])) {
    if (isset($_FILES['backup_file']) && $_FILES['backup_file']['error'] === UPLOAD_ERR_OK) {
        
        // File details
        $fileTmp = $_FILES['backup_file']['tmp_name'];
        $fileName = $_FILES['backup_file']['name'];
        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);

        // Validate uploaded file
        if ($fileExt !== "sql") {
            $message = "❌ Please upload a valid SQL file!";
        } else {
            $database = "ecommerce_db";  // Change to your DB name
            $user = "root";             // Change to your DB username
            $password = "";             // Change if you have DB password
            $host = "localhost";

            // Use mysql command to restore DB
            $command = "mysql --host=$host --user=$user --password=$password $database < $fileTmp";

            // Execute the command
            system($command, $output);

            if ($output === 0) {
                $message = "✅ Database restored successfully!";
            } else {
                $message = "❌ Failed to restore the database!";
            }
        }
    } else {
        $message = "⚠️ Please select a backup `.sql` file to restore.";
    }
}
?>

<?php include("includes/admin_header.php"); ?>

<div class="container my-5">
    <div class="card shadow-lg border-0 rounded-3">
        <div class="card-header bg-dark text-white">
            <h4 class="mb-0"><i class="bi bi-upload"></i> Restore Database</h4>
        </div>
        <div class="card-body">
            <p class="lead text-muted">Select a <b>.sql</b> backup file to restore the database.</p>
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="backup_file" class="form-label fw-bold">Choose SQL File:</label>
                    <input type="file" name="backup_file" id="backup_file" class="form-control" accept=".sql" required>
                </div>
                <button type="submit" name="restore" class="btn btn-danger px-4 py-2">
                    <i class="bi bi-upload"></i> Restore Database
                </button>
            </form>
            <?php if (!empty($message)) : ?>
                <div class="alert alert-info mt-4"><?= $message ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include("includes/admin_footer.php"); ?>
