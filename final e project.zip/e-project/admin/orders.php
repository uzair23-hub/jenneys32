<?php
session_start();
include("../includes/db.php");

// Redirect if admin not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// UPDATE ORDER STATUS
if (isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $query = "UPDATE orders SET status='$status' WHERE id=$order_id";
    if (mysqli_query($conn, $query)) {
        $msg = "<div class='alert alert-success'>✅ Order status updated successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>❌ Error updating status!</div>";
    }
}

// DELETE ORDER
if (isset($_GET['delete'])) {
    $order_id = intval($_GET['delete']);
    $query = "DELETE FROM orders WHERE id=$order_id";
    if (mysqli_query($conn, $query)) {
        $msg = "<div class='alert alert-success'>🗑️ Order deleted successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>❌ Error deleting order!</div>";
    }
}

// Fetch all orders
$orders = mysqli_query($conn, "
    SELECT orders.*, customers.name AS customer_name, customers.email 
    FROM orders 
    JOIN customers ON orders. id = customers.id 
    ORDER BY orders.id DESC
");



?>

<?php include("includes/admin_header.php"); ?>

<div class="container my-4">
    <h2 class="fw-bold mb-4">Manage Orders</h2>

    <!-- Show messages -->
    <?php if (isset($msg)) echo $msg; ?>

    

    <!-- Orders Table -->
    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white">
            <h5 class="m-0">All Orders</h5>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-striped table-hover text-center">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Customer</th>
                        <th>Email</th>
                        
                        <th>Status</th>
                        <th>Order Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($orders) > 0): ?>
                        <?php while ($order = mysqli_fetch_assoc($orders)): ?>

                            <tr>
                                <td><?php echo $order['id'] ?></td>
                                <td><?php echo $order['customer_name'] ?></td>
                                <td><?php echo $order['email'] ?></td>
                                
</td>

                                <td>
                                    <!-- Status Dropdown -->
                                    <form method="POST" class="d-flex justify-content-center">
                                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                        <select name="status" class="form-select form-select-sm w-auto">
                                            <option value="Pending" <?= $order['status'] == "Pending" ? "selected" : "" ?>>Pending</option>
                                            <option value="Processing" <?= $order['status'] == "Processing" ? "selected" : "" ?>>Processing</option>
                                            <option value="Shipped" <?= $order['status'] == "Shipped" ? "selected" : "" ?>>Shipped</option>
                                            <option value="Delivered" <?= $order['status'] == "Delivered" ? "selected" : "" ?>>Delivered</option>
                                            <option value="Cancelled" <?= $order['status'] == "Cancelled" ? "selected" : "" ?>>Cancelled</option>
                                        </select>
                                        <button type="submit" name="update_status" class="btn btn-success btn-sm ms-2">Update</button>
                                    </form>
                                </td>
                                <td><?= date("d M, Y", strtotime($order['order_date'])) ?></td>
                                <td>
                                    <!-- View Details Button -->
                                    <a href="view_order.php?id=<?= $order['id'] ?>" class="btn btn-primary btn-sm">View</a>
                                    <!-- Delete Button -->
                                    <a href="?delete=<?= $order['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this order?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                         
                   
                        <tr>
                            <td colspan="7">No orders found.</td>
                        </tr>
                    <?php endif; ?>
                    
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include("includes/admin_footer.php"); ?>
