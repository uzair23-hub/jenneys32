<?php
session_start();
include("../includes/db.php");

// Redirect if not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch categories for dropdown
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name ASC");

// ADD PRODUCT
if (isset($_POST['add_product'])) {
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $category_id = intval($_POST['category']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $image = $_FILES['image']['name'];

    if (!empty($product_name) && !empty($category_id) && !empty($price) && !empty($stock)) {
        $target_dir = "../uploads/";
        $target_file = $target_dir . basename($image);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Allow only images
        $allowed = ["jpg", "jpeg", "png", "gif"];
        if (!in_array($imageFileType, $allowed)) {
            $msg = "<div class='alert alert-danger'>❌ Only JPG, JPEG, PNG, and GIF files are allowed.</div>";
        } else {
            move_uploaded_file($_FILES['image']['tmp_name'], $target_file);

            $query = "INSERT INTO products (name, category_id, price, stock, description, image) 
                      VALUES ('$product_name', $category_id, $price, $stock, '$description', '$image')";
            if (mysqli_query($conn, $query)) {
                $msg = "<div class='alert alert-success'>✅ Product added successfully!</div>";
            } else {
                $msg = "<div class='alert alert-danger'>❌ Error adding product!</div>";
            }
        }
    } else {
        $msg = "<div class='alert alert-danger'>⚠️ Please fill in all required fields.</div>";
    }
}

// DELETE PRODUCT
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $query = "DELETE FROM products WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        $msg = "<div class='alert alert-success'>🗑️ Product deleted successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>❌ Error deleting product!</div>";
    }
}

// UPDATE PRODUCT
if (isset($_POST['update_product'])) {
    $id = intval($_POST['product_id']);
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $category_id = intval($_POST['category']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // Handle image update
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $target_dir = "../uploads/";
        $target_file = $target_dir . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target_file);

        $query = "UPDATE products SET name='$product_name', category_id=$category_id, price=$price, stock=$stock, description='$description', image='$image' WHERE id=$id";
    } else {
        $query = "UPDATE products SET name='$product_name', category_id=$category_id, price=$price, stock=$stock, description='$description' WHERE id=$id";
    }

    if (mysqli_query($conn, $query)) {
        $msg = "<div class='alert alert-success'>✅ Product updated successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>❌ Error updating product!</div>";
    }
}

// Fetch all products
$products = mysqli_query($conn, "SELECT products.*, categories.name AS category_name FROM products 
                                LEFT JOIN categories ON products.category_id = categories.id ORDER BY products.id DESC");
?>

<?php include("includes/admin_header.php"); ?>

<div class="container my-4">
    <h2 class="fw-bold mb-4">Manage Products</h2>

    <!-- Show messages -->
    <?php if (isset($msg)) echo $msg; ?>

    <!-- Add New Product Form -->
    <div class="card p-4 shadow-sm mb-4">
        <h5>Add New Product</h5>
        <form method="POST" enctype="multipart/form-data">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="product_name" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-control" required>
                        <option value="">Select Category</option>
                        <?php while ($cat = mysqli_fetch_assoc($categories)): ?>
                            <option value="<?= $cat['id'] ?>"><?= $cat['name'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Price</label>
                    <input type="number" name="price" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Stock</label>
                    <input type="number" name="stock" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Image</label>
                    <input type="file"  accept=".jpg,.jpeg,.png" name="image" class="form-control" required>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
                <div class="col-md-12 text-end">
                    <button type="submit" name="add_product" class="btn btn-primary">Add Product</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Products Table -->
    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white">
            <h5 class="m-0">Products List</h5>
        </div>
        <div class="card-body">
            <table class="table table-striped table-hover text-center">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Product</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($products) > 0): ?>
                        <?php while ($prod = mysqli_fetch_assoc($products)): ?>
                            <tr>
                                <td><?= $prod['id'] ?></td>
                                <td><img src="../uploads/<?= $prod['image'] ?>" width="50"></td>
                                <td><?= $prod['name'] ?></td>
                                <td><?= $prod['category_name'] ?></td>
                                <td>PKR <?= number_format($prod['price'], 2) ?></td>
                                <td><?= $prod['stock'] ?></td>
                                <td><?= substr($prod['description'], 0, 50) ?>...</td>
                                <td>
                                    <!-- Edit Button -->
                                    <button class="btn btn-warning btn-sm mb-3" data-bs-toggle="modal" data-bs-target="#editModal<?= $prod['id'] ?>">Edit</button>

                                    <!-- Delete Button -->
                                    <a href="?delete=<?= $prod['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                                </td>
                            </tr>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="editModal<?= $prod['id'] ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header bg-warning">
                                            <h5 class="modal-title">Edit Product</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="POST" enctype="multipart/form-data">
                                            <div class="modal-body">
                                                <input type="hidden" name="product_id" value="<?= $prod['id'] ?>">
                                                <div class="row g-3">
                                                    <div class="col-md-6">
                                                        <label class="form-label">Product Name</label>
                                                        <input type="text" name="product_name" value="<?= $prod['name'] ?>" class="form-control" required>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Category</label>
                                                        <select name="category" class="form-control" required>
                                                            <?php
                                                            $cat_query = mysqli_query($conn, "SELECT * FROM categories");
                                                            while ($cat = mysqli_fetch_assoc($cat_query)) {
                                                                $selected = $cat['id'] == $prod['category_id'] ? 'selected' : '';
                                                                echo "<option value='{$cat['id']}' {$selected}>{$cat['name']}</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label">Price</label>
                                                        <input type="number" name="price" value="<?= $prod['price'] ?>" class="form-control" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label">Stock</label>
                                                        <input type="number" name="stock" value="<?= $prod['stock'] ?>" class="form-control" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label">Image</label>
                                                        <input type="file" name="image" class="form-control">
                                                    </div>
                                                    <div class="col-md-12">
                                                        <label class="form-label">Description</label>
                                                        <textarea name="description" class="form-control" rows="3"><?= $prod['description'] ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" name="update_product" class="btn btn-success">Update</button>
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8">No products found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include("includes/admin_footer.php"); ?>
