-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'alina@gmail.com','asd');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Makeup'),(2,'Skincare\r\n'),(4,'Jewelry'),(5,'Perfumes');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_messages`
--

LOCK TABLES `contact_messages` WRITE;
/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
INSERT INTO `contact_messages` VALUES (1,'Ali','ali@gmail.com','hello','2025-09-06 07:31:49');
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `work_phone` varchar(50) DEFAULT NULL,
  `cell_phone` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `category` varchar(255) NOT NULL DEFAULT 'regular',
  `remarks` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (3,'laiba','nazimabad no2','laiba@gmail.com','03121272498','03121272496','2025-09-30','vip','good'),(4,'Rameen ','Nazimabad no2','rameen@gmail.com','03121272498','03121272496','2025-09-16','vip','good'),(5,'sara','saleem center','sara@gmail.com','03442691908','03366678990','2005-10-15','regular','good'),(6,'habiba','north karachi','habibamanzar@gmail.com','03442691908','03442691908','2000-06-05','regular','good'),(7,'malaika','nazimabad','malika@gmail.com','03214855670','03442691908','2005-02-04','regular','nice');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (3,4,7,3),(4,5,8,1),(5,6,9,1),(6,7,11,1),(7,7,17,1),(8,8,10,1),(9,8,14,1),(10,8,8,1);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (4,3,'','2025-09-04 11:01:00'),(5,4,'','2025-09-04 11:05:46'),(6,5,'Pending','2025-09-05 11:47:19'),(7,6,'Pending','2025-09-05 11:55:29'),(8,7,'','2025-09-05 12:01:37');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (7,1,'lipstick','Enhance your beauty with this long-lasting, highly pigmented lipstick that completes every look with elegance. Its smooth and creamy texture glides effortlessly, leaving your lips soft, moisturized, and crack-free.\r\n\r\n✨ Key Features:\r\n\r\nRich, vibrant color in just one swipe\r\n\r\nLong-lasting wear without fading\r\n\r\nSmooth & creamy application\r\n\r\nMoisturizing formula for soft lips\r\n\r\nAvailable in multiple shades to suit every skin tone\r\n\r\nPerfect for both daily wear and special occasions',2000.00,7,'lipstick img12.jpeg'),(8,4,'Rings','Add a touch of elegance to your style with this beautifully crafted ring, designed to shine on every occasion. Made with high-quality materials, it offers a perfect balance of durability, comfort, and timeless beauty.\r\n\r\n✨ Key Features:\r\n\r\nElegant and stylish design\r\n\r\nCrafted with premium-quality materials\r\n\r\nComfortable fit for everyday wear\r\n\r\nPerfect for weddings, engagements, parties, or gifting\r\n\r\nAvailable in multiple sizes and styles',900.00,8,'jewellery img8.jpeg'),(9,1,' Pink Lipstick','Bring out your natural charm with this soft yet vibrant pink lipstick. Its creamy, smooth texture glides effortlessly, giving your lips a fresh, radiant, and youthful look. Perfect for both casual days and special nights, this pink shade adds a touch of feminine elegance to every style.\r\n\r\n✨ Key Features:\r\n\r\nGorgeous pink shade for all skin tones\r\n\r\nSmooth & creamy formula for easy application\r\n\r\nLong-lasting color without smudging\r\n\r\nKeeps lips soft and moisturized\r\n\r\nPerfect for daily wear, parties, or romantic evenings',1900.00,9,'lipstick img3.jpeg'),(10,1,'Red Lipstick','Turn heads with this bold and classic red lipstick that never goes out of style. With its intense pigmentation and creamy texture, it glides on effortlessly, giving your lips a smooth, flawless, and seductive finish. Perfect for adding confidence and glamour to any look.\r\n\r\n✨ Key Features:\r\n\r\nTimeless red shade for every occasion\r\n\r\nRich, highly pigmented color in one swipe\r\n\r\nSmooth & creamy texture for easy application\r\n\r\nLong-lasting and smudge-proof formula\r\n\r\nKeeps lips soft, moisturized, and irresistible',1500.00,9,'lipstick img1.jpeg'),(11,1,'Nude Lipstick','Achieve the perfect natural look with this elegant nude lipstick. Its soft, creamy formula blends effortlessly, giving your lips a smooth, subtle finish while keeping them hydrated all day. Ideal for everyday wear, office looks, or pairing with bold eye makeup for a balanced style.\r\n\r\n✨ Key Features:\r\n\r\nBeautiful nude shade for a natural look\r\n\r\nSmooth & creamy texture for effortless glide\r\n\r\nLong-lasting color with a lightweight feel\r\n\r\nMoisturizing formula to prevent dryness\r\n\r\nPerfect for daily wear and all skin tones',1700.00,9,'lipstick img11.jpeg'),(12,1,'Lip Gloss','Shine brighter with this glossy, lightweight lip gloss that adds instant sparkle and charm to your lips. Its non-sticky formula glides on smoothly, giving a plump, radiant finish while keeping your lips soft and moisturized. Perfect to wear alone or layer over lipstick for an extra glow.\r\n\r\n✨ Key Features:\r\n\r\nHigh-shine glossy finish\r\n\r\nLightweight & non-sticky formula\r\n\r\nMoisturizing for soft, smooth lips\r\n\r\nWear alone or over lipstick\r\n\r\nPerfect for everyday wear & parties',1000.00,10,'lipstick img 4.jpeg'),(13,1,'Nude Lipstick','Keep it simple yet stunning with this classic nude lipstick. Designed for an effortless everyday look, its creamy, moisturizing formula glides on smoothly, leaving your lips soft, natural, and elegant. Perfect for office wear, casual outings, or pairing with bold eye makeup for balance.\r\n\r\n✨ Key Features:\r\n\r\nElegant nude shade for a natural finish\r\n\r\nSmooth & creamy texture\r\n\r\nLong-lasting, comfortable wear\r\n\r\nHydrates and prevents dryness\r\n\r\nSuitable for all skin tones and occasions',1300.00,10,'lipstick img5.jpeg'),(14,5,'Gucci Perfumes','Experience elegance in every spray with this luxurious perfume, crafted to leave a lasting impression. Its captivating blend of floral, fruity, and woody notes creates a fragrance that is both refreshing and unforgettable. Perfect for daily wear or special occasions, this perfume enhances your personality with charm and sophistication.\r\n\r\n✨ Key Features:\r\n\r\nLong-lasting fragrance\r\n\r\nUnique blend of floral, fruity & woody notes\r\n\r\nElegant and versatile for any occasion\r\n\r\nPremium quality packaging\r\n\r\nPerfect gift for someone special',3000.00,9,'perfume img1.jpg'),(15,5,' Dior Perfumes','Discover the world of Dior perfumes, where timeless elegance meets modern sophistication. Each fragrance is carefully crafted with the finest floral, fruity, and woody notes, creating a scent that is both luxurious and unforgettable.\r\n\r\nFrom the romantic charm of Miss Dior, the bold elegance of J’adore, to the powerful intensity of Sauvage, Dior perfumes are designed to suit every mood, style, and occasion.\r\n\r\n✨ Key Features:\r\n\r\nIconic, long-lasting fragrances\r\n\r\nCrafted with premium natural ingredients\r\n\r\nElegant & sophisticated packaging\r\n\r\nSuitable for daily wear and special events\r\n\r\nA true symbol of luxury and style',3500.00,10,'perfume img2.jpg'),(16,5,'Tom Ford Perfumes','Step into the world of luxury and sophistication with Tom Ford perfumes, crafted for those who dare to stand out. Each fragrance combines bold, sensual, and unforgettable notes, making it a true statement of style and confidence.\r\n\r\nFrom the iconic Black Orchid, the warm sensuality of Tobacco Vanille, to the fresh elegance of Oud Wood, Tom Ford fragrances are designed for both men and women who appreciate timeless luxury.\r\n\r\n✨ Key Features:\r\n\r\nPremium, long-lasting fragrances\r\n\r\nUnique blend of bold & sophisticated notes\r\n\r\nUnisex and gender-specific collections\r\n\r\nElegant designer packaging\r\n\r\nPerfect for special occasions or daily signature wear',4000.00,10,'perfume img3.jpg'),(17,5,'Edge Perfumes','Make every moment unforgettable with Edge Perfume, a fragrance designed for confidence and charm. Blending fresh citrus, spicy, and woody notes, it creates a scent that is both energizing and long-lasting. Perfect for men who want to leave a bold and stylish impression wherever they go.\r\n\r\n✨ Key Features:\r\n\r\nLong-lasting masculine fragrance\r\n\r\nFresh blend of citrus, spice, and woods\r\n\r\nPerfect for daily wear & special occasions\r\n\r\nElegant bottle design\r\n\r\nA scent that defines power and confidence',4500.00,9,'perfume img5.jpg'),(18,5,'Bleu de chanel Perfumes','Unleash your inner strength with Bleu de Chanel, a fragrance that embodies freedom, confidence, and timeless elegance. Crafted for men who dare to be bold, its fresh blend of citrus, woody, and aromatic notes delivers a powerful yet sophisticated scent.\r\n\r\n✨ Key Features:\r\n\r\nIconic men’s fragrance by Chanel\r\n\r\nFresh citrus opening with woody & aromatic depth\r\n\r\nLong-lasting and versatile for day or night\r\n\r\nElegant, masculine bottle design\r\n\r\nPerfect balance of power and sophistication',5000.00,10,'perfume img8.jpg'),(19,5,'Femme Perfumes','Celebrate femininity with Femme Perfume, a fragrance that blends delicate florals, warm musks, and soft fruity notes for a scent that is both graceful and unforgettable. Designed for the modern woman, it leaves a trail of elegance, charm, and confidence wherever you go.\r\n\r\n✨ Key Features:\r\n\r\nElegant floral–fruity fragrance\r\n\r\nLong-lasting & captivating scent\r\n\r\nPerfect for daily wear and special occasions\r\n\r\nStylish and feminine packaging\r\n\r\nA fragrance that enhances natural beauty',5000.00,10,'perfume img7.jpg'),(20,4,'Locket Chain','Carry your memories close to your heart with this elegant locket chain. Beautifully crafted with premium-quality material, the locket opens to hold a photo or a small keepsake, making it both stylish and meaningful. Its timeless design adds a touch of grace and sophistication to any outfit, whether casual or formal.\r\n\r\n✨ Key Features:\r\n\r\nElegant and durable design\r\n\r\nOpens to hold photos or tiny keepsakes\r\n\r\nPerfect for daily wear or special occasions\r\n\r\nA thoughtful gift for loved ones\r\n\r\nAvailable in multiple styles and finishes',500.00,10,'jewellery img6.jpeg'),(21,4,'Chains','Add effortless style to your look with these versatile chains, designed to suit every occasion. Crafted with high-quality materials, they combine durability, comfort, and elegance, making them a must-have accessory for both men and women. Wear them solo for a minimalist vibe or pair with pendants for a bold statement.\r\n\r\n✨ Key Features:\r\n\r\nStylish and durable design\r\n\r\nSuitable for daily wear or special occasions\r\n\r\nAvailable in multiple lengths and styles\r\n\r\nPerfect for layering or wearing with pendants\r\n\r\nA timeless accessory for men and women',600.00,10,'jewellery img16.jpeg'),(22,4,'Chain Locket sey','Elegant Chain Locket Set\r\nEnhance your style with this beautiful chain locket set, designed to add a touch of elegance to your look. The set includes a delicate chain with a stylish locket and matching earrings, making it perfect for both casual wear and special occasions.\r\n\r\n✨ Features:\r\n\r\nPremium-quality material with fine finishing\r\n\r\nLightweight and comfortable to wear all day\r\n\r\nStylish design suitable for parties, weddings, or daily wear\r\n\r\nPerfect gift for birthdays, anniversaries, or special events',1000.00,10,'jewellery img2.jpeg'),(23,4,' Gold Chain Set','Add timeless elegance to your style with this beautifully crafted gold chain. Designed with a sleek and durable finish, it’s perfect to wear alone for a minimalist look or paired with a pendant for a bold statement.\r\n\r\n✨ Features:\r\n\r\nMade with high-quality gold plating / pure gold (as per product)\r\n\r\nSmooth and comfortable to wear every day\r\n\r\nElegant design suitable for both men and women\r\n\r\nPerfect for daily wear, parties, or gifting on special occasions',5000.00,10,'jewellery img13.jpeg'),(24,4,'Necklace chain','Elevate your beauty with this gracefully designed necklace, perfect for adding charm to any outfit. Whether worn alone or paired with matching jewelry, this piece is sure to make you stand out.\r\n\r\n✨ Features:\r\n\r\nPremium-quality craftsmanship with fine finishing\r\n\r\nElegant and versatile design for any occasion\r\n\r\nLightweight and comfortable to wear all day\r\n\r\nPerfect choice for parties, weddings, or daily wear\r\n\r\nA thoughtful gift for someone special',5500.00,10,'jewellery img19.jpeg'),(25,4,'Rings Set','Add a touch of sophistication to your style with this stunning ring set. Designed with elegance and comfort in mind, this set includes beautifully crafted rings that can be worn together for a bold look or separately for a subtle charm.\r\n\r\n✨ Features:\r\n\r\nPremium-quality material with long-lasting shine\r\n\r\nStylish and versatile designs for every occasion\r\n\r\nLightweight, comfortable, and easy to wear\r\n\r\nPerfect for parties, weddings, engagements, or daily wear\r\n\r\nA wonderful gift choice for birthdays, anniversaries, or special moments',1500.00,10,'jewellery img15.jpeg'),(26,4,'Ring Box','Keep your precious rings safe and beautifully presented with this elegant ring box. Designed with soft cushioning and a durable exterior, it’s perfect for engagements, weddings, proposals, or gifting.\r\n\r\n✨ Features:\r\n\r\nHigh-quality material with smooth finishing\r\n\r\nSoft velvet/foam lining to protect your jewelry\r\n\r\nCompact, lightweight, and travel-friendly\r\n\r\nElegant design suitable for special occasions\r\n\r\nPerfect for engagement rings, wedding bands, or gifting',2000.00,10,'jewellery img21.jpeg'),(27,4,'Rings','Enhance your look with these beautifully crafted rings, designed to add elegance and charm to any outfit. Perfect for daily wear or special occasions, these rings are a timeless addition to your jewelry collection.\r\n\r\n✨ Features:\r\n\r\nHigh-quality material with lasting shine\r\n\r\nElegant and versatile designs for men and women\r\n\r\nLightweight and comfortable to wear all day\r\n\r\nSuitable for parties, weddings, engagements, or casual wear\r\n\r\nAn ideal gift for birthdays, anniversaries, or special celebrations',2000.00,10,'jewellery img25.jpeg'),(28,4,'Bracelet set','Add a touch of beauty and sophistication to your style with this stunning bracelet set. Designed with elegance and comfort, these bracelets can be worn individually for a simple look or stacked together for a bold fashion statement.\r\n\r\n✨ Features:\r\n\r\nPremium-quality material with long-lasting shine\r\n\r\nLightweight, durable, and comfortable for daily wear\r\n\r\nStylish and versatile design suitable for any outfit\r\n\r\nPerfect for parties, weddings, or casual occasions\r\n\r\nAn ideal gift for birthdays, anniversaries, or special celebrations',1500.00,10,'jewellery img12.jpeg'),(29,1,'Pen Liner','Our Pen Liner is designed to give you the perfect eye look with ultimate ease. With its pen-style precision tip, you can create sharp wings, bold lines, or soft everyday looks effortlessly. The formula is lightweight, quick-drying, and long-lasting to keep your eyes looking defined and beautiful all day.\r\n\r\nKey Features:\r\n\r\n✨ Precise Tip: Ultra-fine pen tip for sharp and smooth application.\r\n\r\n💧 Smudge-Proof: Stays in place without smearing or fading.\r\n\r\n⏱ Quick-Drying: No waiting, no mess—dries in seconds.\r\n\r\n⌛ Long-Lasting: Keeps your look fresh for up to 12–24 hours.\r\n\r\n🌿 Gentle Formula: Suitable for sensitive eyes and contact lens wearers.\r\n\r\n🎨 Versatile Looks: Perfect for bold, dramatic wings or natural, subtle lines.',450.00,10,'image23.jpg'),(30,1,'Liquid Liner','Our Liquid Liner is the ultimate choice for bold, defined, and dramatic eyes. With its rich, highly pigmented formula and smooth applicator, it delivers intense color in just one stroke. Whether you want a sleek everyday look or a striking cat-eye, this liner ensures precision and style that lasts all day.\r\n\r\nKey Features:\r\n\r\n🎯 Precision Applicator: Designed for sharp, clean, and smooth lines.\r\n\r\n🎨 Rich Pigment: Deep, intense color for maximum impact.\r\n\r\n💧 Smudge & Water-Resistant: Stays flawless without smearing.\r\n\r\n⌛ Long-Lasting Wear: Keeps your look intact for hours.\r\n\r\n✨ Quick-Drying Formula: No waiting, no transfer.\r\n\r\n🌿 Gentle & Lightweight: Comfortable for daily wear.',500.00,10,'image29.jpg'),(31,1,'Blue Liner','Blue Liner Description:\r\nAdd a pop of color to your eyes with our stunning Blue Liner. Its bold, vibrant pigment glides on smoothly to create striking looks that stand out. Perfect for both everyday wear and special occasions, this liner combines style with long-lasting comfort.\r\n\r\nKey Features:\r\n\r\n💙 Vibrant Blue Shade: Makes eyes look brighter and more expressive.\r\n\r\n🎯 Precision Tip/Applicator: Allows clean, sharp, and effortless application.\r\n\r\n💧 Smudge-Proof & Water-Resistant: Stays put all day without fading.\r\n\r\n⌛ Long-Lasting Formula: Keeps your eye look fresh for hours.\r\n\r\n✨ Quick-Drying: No mess, no transfer.\r\n\r\n🌿 Lightweight & Gentle: Suitable for all skin types and daily wear.',300.00,10,'image30.jpg'),(32,1,'Maybelline Mascara','Maybelline Mascara is designed to give your lashes instant volume, length, and definition. With its smooth, clump-free formula and precision brush, it coats every lash from root to tip for a bold, dramatic eye look. Perfect for both everyday wear and glamorous occasions, this mascara keeps your lashes looking fuller and more striking all day long.\r\n\r\nKey Features:\r\n\r\n👁 Instant Volume & Length: Makes lashes look fuller and longer in seconds.\r\n\r\n🎯 Precision Brush: Separates and defines each lash without clumping.\r\n\r\n💧 Smudge-Proof & Waterproof Options: Keeps your look intact all day.\r\n\r\n✨ Intense Black Pigment: Deep, bold color for striking eyes.\r\n\r\n🌿 Gentle Formula: Safe for sensitive eyes and contact lens wearers.\r\n\r\n⌛ Long-Lasting Wear: Stays fresh from morning to night.',1000.00,10,'image22.jpg'),(33,1,'EYEKO Beach Waterproof Mascara','Eyeko Beach Waterproof Mascara Description:\r\nEyeko Beach Waterproof Mascara is your perfect partner for long, voluminous lashes that last from sunrise to sunset. Designed with a wave-shaped brush, it lifts, curls, and defines each lash while the waterproof formula keeps your look intact—whether you’re at the beach, by the pool, or out in the sun. Infused with coconut oil and 12 fruit extracts, it nourishes while delivering intense, smudge-proof color.\r\n\r\nKey Features:\r\n\r\n🌊 Waterproof Formula: Stays flawless through humidity, sweat, and splashes.\r\n\r\n👁 Wave-Shaped Brush: Lifts, curls, and separates lashes effortlessly.\r\n\r\n✨ Volumizing & Lengthening: Adds dramatic definition in one coat.\r\n\r\n💧 Smudge-Proof & Long-Lasting: Keeps your lashes fresh all day.\r\n\r\n🌿 Infused with Coconut Oil & Fruit Extracts: Nourishes and conditions lashes.\r\n\r\n🏖 Perfect for Beach & Outdoor Wear: Designed to withstand heat and water.',1500.00,10,'image24.jpg'),(34,1,'Face Powder','Our Face Powder is designed to give you a flawless, smooth, and natural-looking finish. Its lightweight formula controls shine, sets makeup, and keeps your skin fresh all day. Perfect for touch-ups, it blends seamlessly without caking, leaving your complexion soft and radiant.\r\n\r\nKey Features:\r\n\r\n✨ Flawless Finish: Evens out skin tone for a smooth, natural look.\r\n\r\n💧 Oil & Shine Control: Keeps your skin matte and fresh.\r\n\r\n🌿 Lightweight Formula: Comfortable wear without feeling heavy.\r\n\r\n🎯 Buildable Coverage: Can be used alone or to set foundation.\r\n\r\n⌛ Long-Lasting Wear: Keeps makeup in place throughout the day.\r\n\r\n👜 Portable & Easy-to-Use: Perfect for quick touch-ups on the go.',5000.00,10,'powder img1.jpeg'),(35,1,'Maybelline Face Powder','Maybelline Face Powder Description:\r\nMaybelline Face Powder gives you a smooth, shine-free, and natural-looking finish that lasts all day. With its lightweight texture and buildable coverage, it evens out skin tone, blurs imperfections, and keeps your makeup fresh. Perfect for everyday wear, this powder can be used alone for a soft matte look or on top of foundation to set and lock makeup in place.\r\n\r\nKey Features:\r\n\r\n✨ Smooth & Natural Finish: Blends seamlessly with skin.\r\n\r\n💧 Oil & Shine Control: Keeps your skin matte for hours.\r\n\r\n🎯 Buildable Coverage: Wear it alone or over foundation.\r\n\r\n🌿 Lightweight Formula: Comfortable for daily use.\r\n\r\n⌛ Long-Lasting Wear: Keeps makeup intact all day.\r\n\r\n👜 Compact & Travel-Friendly: Easy to carry for quick touch-ups.',5500.00,10,'image14.jpg'),(36,1,'Foundation','Foundation Description:\r\nOur Foundation is designed to give your skin a flawless, even-toned, and natural finish. With its lightweight and blendable formula, it provides buildable coverage that hides imperfections while keeping your skin comfortable and fresh. Suitable for all skin types, it enhances your natural beauty and ensures long-lasting wear.\r\n\r\nKey Features:\r\n\r\n✨ Flawless Coverage: Smoothly evens out skin tone and hides imperfections.\r\n\r\n🌿 Lightweight Formula: Feels breathable and comfortable all day.\r\n\r\n🎯 Buildable Coverage: From natural to full glam—your choice.\r\n\r\n💧 Hydrating & Non-Cakey: Keeps skin soft without drying out.\r\n\r\n⌛ Long-Lasting Wear: Maintains a fresh look for hours.\r\n\r\n🌍 Suitable for All Skin Types: Works well on oily, dry, or combination skin.',6500.00,10,'image32.jpg'),(37,1,'Eye Shadow','Eye Shadow Description:\r\nOur Eye Shadow palette brings endless possibilities to your makeup looks. With richly pigmented shades and a silky-smooth formula, it blends effortlessly for both subtle daytime styles and bold, dramatic night looks. From mattes to shimmers, each shade is designed to enhance your eyes with vibrant, long-lasting color.\r\n\r\nKey Features:\r\n\r\n🎨 Richly Pigmented Colors: Delivers intense, true-to-pan shades.\r\n\r\n✨ Matte & Shimmer Finishes: Perfect for versatile looks.\r\n\r\n🌿 Silky & Blendable Texture: Glides on smoothly without creasing.\r\n\r\n⌛ Long-Lasting Wear: Keeps your eye look fresh all day.\r\n\r\n🎯 Buildable Coverage: Layer shades for natural or dramatic results.\r\n\r\n👜 Travel-Friendly Palette: Compact design for beauty on the go.',7000.00,10,'image42.jpg'),(38,1,'Makeup Eye Shadow 4 colors pallets','4-Color Eye Shadow Palette Description:\r\nOur 4-Color Eye Shadow Palette is the perfect compact set for creating versatile eye looks. With a mix of matte and shimmer shades, it offers everything you need for soft everyday styles or bold evening glam. The silky, blendable formula glides smoothly onto the lids, delivering vibrant color payoff that lasts all day.\r\n\r\nKey Features:\r\n\r\n🎨 4 Coordinated Shades: Designed for effortless mixing and matching.\r\n\r\n✨ Matte & Shimmer Finishes: Create natural, smoky, or glam looks.\r\n\r\n🌿 Smooth & Blendable Formula: Applies evenly without creasing.\r\n\r\n💎 Rich Pigmentation: Delivers true, long-lasting color.\r\n\r\n⌛ Compact & Travel-Friendly: Perfect for on-the-go touch-ups.\r\n\r\n👁 Versatile Use: Suitable for day-to-night makeup.',2000.00,10,'image41.jpg'),(39,1,'Highlighter','Highlighter Description:\r\nOur Highlighter is designed to give your skin a radiant, glowing finish. With its silky texture and luminous pigments, it enhances your natural features by adding light and dimension to your face. Perfect for cheeks, brow bones, nose, and cupid’s bow, this highlighter delivers a soft shimmer or a bold glow—your choice!\r\n\r\nKey Features:\r\n\r\n✨ Radiant Glow: Adds instant brightness and dimension.\r\n\r\n🌿 Silky Smooth Texture: Blends seamlessly into skin.\r\n\r\n🎨 Buildable Intensity: From natural sheen to bold shine.\r\n\r\n💎 Long-Lasting Wear: Keeps your glow fresh all day.\r\n\r\n👩‍🎨 Multi-Use: Apply on face, eyes, or body for extra sparkle.\r\n\r\n👜 Compact & Easy to Carry: Perfect for everyday use or travel.',2500.00,10,'image21.jpg'),(40,1,'Blush','Blush Description:\r\nOur Blush adds a natural flush of color to your cheeks, giving your face a healthy, radiant glow. With its smooth, blendable texture and lightweight formula, it melts seamlessly into the skin for a fresh and youthful finish. Perfect for everyday wear or glam looks, this blush enhances your natural beauty effortlessly.\r\n\r\nKey Features:\r\n\r\n🌸 Natural Color Payoff: Gives a soft, radiant flush.\r\n\r\n✨ Silky & Blendable Formula: Smooth application without patchiness.\r\n\r\n🌿 Lightweight & Breathable: Comfortable for all-day wear.\r\n\r\n🎨 Buildable Coverage: From soft, natural tones to bold color.\r\n\r\n💎 Long-Lasting Wear: Keeps your cheeks glowing for hours.\r\n\r\n👜 Compact & Travel-Friendly: Easy to carry for touch-ups.',3200.00,10,'image15.jpg'),(41,1,'Artdeco Blush Stick','ARTDECO Blush Stick Description:\r\nThe ARTDECO Blush Stick is a creamy, easy-to-apply blush that delivers a fresh and radiant pop of color to your cheeks. Its smooth texture blends seamlessly into the skin, giving a natural and dewy finish. Perfect for on-the-go touch-ups, this stick format makes application quick, effortless, and precise.\r\n\r\nKey Features:\r\n\r\n🌸 Creamy Texture: Glides smoothly onto the skin without streaks.\r\n\r\n✨ Natural & Radiant Finish: Adds a healthy, fresh glow to cheeks.\r\n\r\n🎯 Buildable Coverage: From a soft flush to more intense color.\r\n\r\n👜 Stick Format: Compact, travel-friendly, and easy to use anywhere.\r\n\r\n🌿 Lightweight & Comfortable: Suitable for all skin types.\r\n\r\n⌛ Long-Lasting Wear: Keeps your cheeks glowing throughout the day.',2500.00,10,'image18.jpg'),(42,1,'Essence Baby Blush Stick','Essence Baby Blush Stick Description:\r\nThe Essence Baby Blush Stick gives your cheeks a soft, natural-looking flush in just one swipe. With its creamy, lightweight texture, it blends effortlessly into the skin for a fresh and radiant glow. Its compact stick design makes it easy to apply and perfect for quick touch-ups on the go.\r\n\r\nKey Features:\r\n\r\n🌸 Natural Flush of Color: Creates a healthy, youthful glow.\r\n\r\n✨ Creamy & Blendable Formula: Smooth application without patchiness.\r\n\r\n🎯 Buildable Coverage: From soft sheer color to more vibrant results.\r\n\r\n👜 Travel-Friendly Stick: Easy to carry for on-the-go use.\r\n\r\n🌿 Lightweight & Comfortable: Suitable for all skin types.\r\n\r\n💎 Long-Lasting Wear: Keeps your cheeks fresh all day.',1700.00,10,'image16.jpg'),(43,4,'Silver Bracelet','Silver Bracelet Description:\r\nA timeless accessory, this Silver Bracelet adds elegance and charm to any outfit. Crafted with fine-quality silver, it features a sleek design that complements both casual and formal looks. Lightweight yet durable, it’s perfect for daily wear or as a thoughtful gift for someone special.\r\n\r\nKey Features:\r\n\r\n💎 Pure Silver Shine: Beautifully polished for a classic look.\r\n\r\n✨ Elegant & Versatile Design: Matches any outfit or occasion.\r\n\r\n🌿 Skin-Friendly Material: Gentle on sensitive skin.\r\n\r\n⌛ Durable & Long-Lasting: Made with high-quality craftsmanship.\r\n\r\n🎁 Perfect Gift Choice: Ideal for birthdays, anniversaries, or special moments.\r\n\r\n👜 Lightweight & Comfortable: Easy to wear all day long.',1300.00,10,'image1.jpg'),(44,4,'Gold Bracelet','Gold Bracelet Description:\r\nThis elegant Gold Bracelet is a symbol of timeless beauty and sophistication. Crafted with fine-quality gold, it adds a touch of luxury and charm to any style. Whether worn daily or on special occasions, its classic design makes it a perfect accessory and a meaningful gift.\r\n\r\nKey Features:\r\n\r\n💛 Premium Gold Finish: Radiant shine with lasting elegance.\r\n\r\n✨ Classic & Versatile Design: Complements both casual and formal looks.\r\n\r\n🌿 Skin-Friendly Material: Gentle and comfortable on the skin.\r\n\r\n⌛ Durable & Long-Lasting: Crafted for everyday wear.\r\n\r\n🎁 Perfect Gift Option: Ideal for weddings, anniversaries, or special celebrations.\r\n\r\n👜 Lightweight & Comfortable Fit: Easy to style and wear all day.\r\n',1200.00,10,'image2.jpg'),(45,2,'Coffe Facewash','Coffee Face Wash Description:\r\nOur Coffee Face Wash is enriched with natural coffee extracts to awaken and refresh your skin. It deeply cleanses away dirt, oil, and impurities while leaving your skin soft, smooth, and energized. Infused with antioxidants, this face wash helps to brighten your complexion and give you a healthy, radiant glow.\r\n\r\nKey Features:\r\n\r\n☕ Coffee-Infused Formula: Energizes and refreshes tired skin.\r\n\r\n✨ Deep Cleansing: Removes dirt, oil, and impurities effectively.\r\n\r\n🌿 Rich in Antioxidants: Helps fight dullness and protects skin.\r\n\r\n💧 Hydrating & Gentle: Leaves skin soft without over-drying.\r\n\r\n👩‍⚕️ Suitable for All Skin Types: Safe for daily use.\r\n\r\n🌸 Brightening Effect: Promotes a fresh, glowing complexion.',2200.00,10,'image11.jpg'),(46,2,'Curology\'s Gentle Cleanser','Curology Gentle Cleanser Description:\r\nCurology’s Gentle Cleanser is a dermatologist-designed formula that cleans your skin without stripping it of its natural moisture. With a light, gel-like texture, it removes dirt, oil, and buildup while keeping your skin soft, balanced, and refreshed. Perfect for daily use, it’s made with gentle, non-clogging ingredients suitable for all skin types—even sensitive skin.\r\n\r\nKey Features:\r\n\r\n🌿 Gentle Formula: Cleanses without irritation or dryness.\r\n\r\n💧 Hydrating & Soothing: Helps maintain skin’s natural moisture barrier.\r\n\r\n✨ Light Gel Texture: Smooth, refreshing, and easy to rinse.\r\n\r\n👩‍⚕️ Dermatologist-Designed: Backed by skin experts for safe daily use.\r\n\r\n🚫 Non-Comedogenic: Won’t clog pores—ideal for acne-prone skin.\r\n\r\n🌸 Suitable for All Skin Types: Works well on normal, oily, dry, and sensitive skin.',1900.00,10,'image12.jpg'),(47,2,'Lacon Oleogel Soft Make-Up Remover','Lacon Oleogel Soft Make-Up Remover Description:\r\nLacon Oleogel Soft Make-Up Remover gently dissolves and lifts away makeup, dirt, and impurities without irritating the skin. Its soft, oil-gel texture glides smoothly over the face, leaving skin clean, nourished, and refreshed. Enriched with moisturizing ingredients, it helps maintain the skin’s natural balance, making it perfect for daily use—even on sensitive skin.\r\n\r\nKey Features:\r\n\r\n🧴 Soft Oil-Gel Formula: Melts away makeup effortlessly.\r\n\r\n✨ Gentle & Non-Irritating: Suitable for sensitive skin and eyes.\r\n\r\n💧 Moisturizing Effect: Leaves skin soft, hydrated, and smooth.\r\n\r\n🚫 Effective on All Makeup: Removes waterproof and long-wear products.\r\n\r\n🌿 Skin-Friendly Ingredients: Nourishes while cleansing.\r\n\r\n👩‍⚕️ Dermatologically Tested: Safe for everyday use.',700.00,10,'image13.jpg'),(48,2,'Clarins Moisture Rich Body Lotion','Clarins Moisture-Rich Body Lotion Description:\r\nClarins Moisture-Rich Body Lotion is a luxurious, nourishing formula that delivers intense hydration and silky softness to dry skin. Enriched with shea butter and natural plant extracts, it smooths rough areas, restores comfort, and leaves skin feeling supple and radiant. Its creamy texture absorbs quickly without greasiness, making it perfect for daily use.\r\n\r\nKey Features:\r\n\r\n💧 Deep Hydration: Intensely moisturizes dry and rough skin.\r\n\r\n🌿 Shea Butter & Plant Extracts: Nourishes and restores skin’s softness.\r\n\r\n✨ Silky Smooth Texture: Leaves skin soft, radiant, and comfortable.\r\n\r\n🚫 Non-Greasy Formula: Absorbs quickly for everyday wear.\r\n\r\n🌸 Restores Elasticity: Improves skin’s suppleness and smoothness.\r\n\r\n👩‍⚕️ Dermatologically Tested: Gentle and safe for daily use.',12600.00,10,'image34.jpg'),(49,2,'Brightening Cleansing Milk','Brightening Cleansing Milk Description:\r\nOur Brightening Cleansing Milk is a gentle yet effective cleanser that removes makeup, dirt, and impurities while nourishing the skin. Enriched with brightening ingredients, it helps even out skin tone, reduce dullness, and reveal a fresh, radiant glow. Its silky, milky texture soothes and hydrates, leaving your skin soft, clean, and luminous.\r\n\r\nKey Features:\r\n\r\n✨ Brightening Effect: Promotes a radiant, glowing complexion.\r\n\r\n🧴 Gentle Milky Formula: Cleanses without stripping natural oils.\r\n\r\n💧 Hydrating & Soothing: Keeps skin soft, smooth, and comfortable.\r\n\r\n🌿 Enriched with Natural Extracts: Supports skin clarity and nourishment.\r\n\r\n🚫 Removes Makeup & Impurities: Effective on light to moderate makeup.\r\n\r\n👩‍⚕️ Suitable for All Skin Types: Especially ideal for dry and sensitive skin.',470.00,10,'image37.jpg'),(50,2,'Rose Soothing Cleansing','Rose Soothing Cleansing Description:\r\nOur Rose Soothing Cleanser gently removes dirt, oil, and makeup while calming and refreshing the skin. Infused with natural rose extracts, it helps soothe irritation, hydrate, and restore balance, leaving your skin soft, clean, and delicately refreshed with a light floral touch. Perfect for sensitive or tired skin in need of gentle care.\r\n\r\nKey Features:\r\n\r\n🌹 Infused with Rose Extracts: Calms, refreshes, and nourishes skin.\r\n\r\n💧 Gentle Cleansing: Removes makeup and impurities without drying.\r\n\r\n🌿 Soothing Formula: Helps reduce redness and irritation.\r\n\r\n✨ Hydrating Effect: Leaves skin soft, smooth, and comfortable.\r\n\r\n🚫 Mild & Non-Irritating: Suitable for sensitive and delicate skin.\r\n\r\n🌸 Delicate Floral Touch: Refreshes with a subtle rose fragrance.',1360.00,10,'image36.jpg'),(51,2,'Aveeno Daily Moisturizing Lotion','Aveeno Daily Moisturizing Lotion Description:\r\nAveeno Daily Moisturizing Lotion is clinically proven to improve the health of dry skin in just one day, with significant results in two weeks. Enriched with colloidal oatmeal and rich emollients, this nourishing lotion locks in moisture and helps prevent and protect dry skin. Its non-greasy, fast-absorbing formula leaves skin soft, smooth, and healthy-looking all day long.\r\n\r\nKey Features:\r\n\r\n🌾 Colloidal Oatmeal Formula: Soothes and nourishes dry skin.\r\n\r\n💧 24-Hour Hydration: Provides long-lasting moisture.\r\n\r\n✨ Clinically Proven Results: Improves skin health in 1 day.\r\n\r\n🚫 Non-Greasy & Fast Absorbing: Comfortable for daily use.\r\n\r\n🌿 Fragrance-Free & Gentle: Suitable for sensitive skin.\r\n\r\n👩‍⚕️ Dermatologist Recommended: Safe and effective for everyday skincare.',5560.00,10,'image35.jpg'),(52,2,'Necessaire Pump Body Lotion','Nécessaire The Body Lotion (Pump) Description:\r\nNécessaire The Body Lotion is a fast-absorbing, fragrance-free moisturizer designed to nourish, replenish, and strengthen the skin barrier. Packed with multi-vitamins (A, C, E), Niacinamide, and Omegas 6 & 9, this lightweight lotion delivers long-lasting hydration while improving skin tone and texture. With its sleek pump design, it’s both luxurious and convenient for everyday body care.\r\n\r\nKey Features:\r\n\r\n💧 Deep Hydration: Lightweight lotion that locks in moisture.\r\n\r\n🌿 Clean, Effective Formula: Infused with Vitamins A, C, E + Niacinamide + Omegas 6 & 9.\r\n\r\n✨ Skin Barrier Support: Strengthens and replenishes skin health.\r\n\r\n🚫 Fragrance-Free & Gentle: Ideal for sensitive skin.\r\n\r\n🧴 Pump Packaging: Easy, hygienic, and convenient application.\r\n\r\n👩‍⚕️ Dermatologist-Tested: Safe for daily use on all skin types.',15000.00,10,'image33.jpg'),(53,1,'Eyeshadow Palette','Eyeshadow Palette Description:\r\nOur Eyeshadow Palette offers a stunning range of shades to create endless eye looks—from soft daytime styles to bold, dramatic glam. With richly pigmented colors in matte, shimmer, and metallic finishes, each shade blends effortlessly for smooth, professional results. Compact and versatile, this palette is perfect for both beginners and makeup lovers.\r\n\r\nKey Features:\r\n\r\n🎨 Versatile Shades: A mix of mattes, shimmers, and metallics.\r\n\r\n✨ Rich Pigmentation: Delivers vibrant, true-to-pan color payoff.\r\n\r\n🌿 Silky, Blendable Texture: Easy application without creasing.\r\n\r\n🎯 Buildable Coverage: Layer for natural to bold looks.\r\n\r\n⌛ Long-Lasting Formula: Keeps your eye look fresh all day.\r\n\r\n👜 Compact & Travel-Friendly: Perfect for beauty on the go.',1800.00,10,'image4.jpg'),(54,2,'Char Coal Facemask','Charcoal Face Mask Description:\r\nOur Charcoal Face Mask is formulated to deeply cleanse and detoxify the skin. Infused with activated charcoal, it draws out dirt, oil, and impurities from pores, leaving your skin fresh, smooth, and clear. Perfect for oily and combination skin, this mask helps reduce blackheads and shine while giving your complexion a healthy, balanced glow.\r\n\r\nKey Features:\r\n\r\n🖤 Activated Charcoal Formula: Pulls out dirt, toxins, and impurities.\r\n\r\n✨ Deep Pore Cleansing: Helps unclog pores and reduce blackheads.\r\n\r\n💧 Oil & Shine Control: Leaves skin matte and refreshed.\r\n\r\n🌿 Skin-Purifying Effect: Promotes a healthy, balanced complexion.\r\n\r\n👩‍⚕️ Suitable for Oily/Combination Skin: Gentle yet effective formula.\r\n\r\n⌛ Refreshing Glow: Reveals smoother and cleaner skin instantly.',800.00,10,'image5.jpg');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-06 15:42:28
