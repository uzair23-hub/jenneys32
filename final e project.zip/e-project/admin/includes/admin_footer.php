<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Janny's Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Sticky Responsive Footer -->
    <style>
      body {
        min-height: 100vh;
        display: flex;
        flex-direction: column;
      }
      .site-footer {
        margin-top: auto;
        width: 100%;
        background-color: black;
        color: #fff;
        text-align: center;
        padding: 1.5rem 2rem;
        box-shadow: 0 4px 24px rgba(233, 30, 99, 0.08);
        position: relative;
        left: 0;
        bottom: 0;
      }
      @media (max-width: 600px) {
        .site-footer {
          padding: 1rem;
          font-size: 0.95rem;
        }
      }
    </style>
</head>
<body class="d-flex flex-column">
    <!-- Your content here -->
    <footer class="site-footer">
      <div style="font-family: 'Poppins', sans-serif; font-size: 1.1rem;">
        &copy; <?= date("Y"); ?> Janny's Store | Admin Panel
      </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
