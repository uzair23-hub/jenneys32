<?php
session_start();
include("../includes/db.php");

// Redirect if admin is not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch Top 10 Best-Selling Products
$product_query = mysqli_query($conn, "
    SELECT p.name, SUM(oi.quantity) AS total_sold
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    GROUP BY oi.product_id
    ORDER BY total_sold DESC
    LIMIT 10
");

$product_names = [];
$product_sales = [];
while ($row = mysqli_fetch_assoc($product_query)) {
    $product_names[] = $row['name'];
    $product_sales[] = $row['total_sold'];
}

$customer_query = mysqli_query($conn, "
    SELECT u.name, SUM(oi.quantity * p.price) AS total_spent
    FROM orders o
    JOIN customers u ON o.customer_id = u.id
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    GROUP BY u.id
    ORDER BY total_spent DESC
    LIMIT 10
");


$customer_names = [];
$customer_spent = [];
while ($row = mysqli_fetch_assoc($customer_query)) {
    $customer_names[] = $row['name'];
    $customer_spent[] = $row['total_spent'];
}
?>

<?php include("includes/admin_header.php"); ?>

<div class="container my-4">
    <h2 class="fw-bold mb-3">📊 Reports Dashboard</h2>
    <p class="text-muted">Visual insights about your products and customers</p>

    <div class="row g-4">
        <!-- Top Selling Products -->
        <div class="col-lg-6 col-md-12">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="m-0">Top 10 Best-Selling Products</h5>
                </div>
                <div class="card-body">
                    <canvas id="productChart" height="280"></canvas>
                </div>
            </div>
        </div>

        <!-- Top Customers -->
        <div class="col-lg-6 col-md-12">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h5 class="m-0">Top 10 Customers</h5>
                </div>
                <div class="card-body">
                    <canvas id="customerChart" height="280"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Top Selling Products Chart
    const ctxProducts = document.getElementById('productChart').getContext('2d');
    new Chart(ctxProducts, {
        type: 'bar',
        data: {
            labels: <?= json_encode($product_names) ?>,
            datasets: [{
                label: 'Units Sold',
                data: <?= json_encode($product_sales) ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.7)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#333',
                    titleFont: { size: 14 },
                    bodyFont: { size: 13 }
                }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    // Top Customers Chart
    const ctxCustomers = document.getElementById('customerChart').getContext('2d');
    new Chart(ctxCustomers, {
        type: 'doughnut',
        data: {
            labels: <?= json_encode($customer_names) ?>,
            datasets: [{
                label: 'Total Spent (PKR)',
                data: <?= json_encode($customer_spent) ?>,
                backgroundColor: [
                    '#36A2EB', '#FF6384', '#4BC0C0', '#9966FF', '#FF9F40',
                    '#66BB6A', '#FFA726', '#AB47BC', '#29B6F6', '#EF5350'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { font: { size: 12 } }
                }
            }
        }
    });
</script>

<?php include("includes/admin_footer.php"); ?>
