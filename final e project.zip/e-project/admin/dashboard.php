<?php
session_start();
include("../includes/db.php");

// Check admin authentication
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Count statistics
$total_products = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM products"))['count'];
$total_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM orders"))['count'];
$total_customers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM customers"))['count'];
?>

<?php include("includes/admin_header.php"); ?>

<div class="container my-4">
    <h2 class="fw-bold mb-4">Admin Dashboard</h2>
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card shadow p-4 text-center bg-primary text-white">
                <h4>Total Products</h4>
                <h2><?= $total_products ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow p-4 text-center bg-success text-white">
                <h4>Total Orders</h4>
                <h2><?= $total_orders ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow p-4 text-center bg-warning text-dark">
                <h4>Total Customers</h4>
                <h2><?= $total_customers ?></h2>
            </div>
        </div>
    </div>
</div>

<?php include("includes/admin_footer.php"); ?>
