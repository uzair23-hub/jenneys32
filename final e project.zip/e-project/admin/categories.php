<?php
session_start();
include("../includes/db.php");

// Redirect if not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// ADD CATEGORY
if (isset($_POST['add_category'])) {
    $category_name = mysqli_real_escape_string($conn, $_POST['category_name']);

    if (!empty($category_name)) {
        $check = mysqli_query($conn, "SELECT * FROM categories WHERE name='$category_name'");
        if (mysqli_num_rows($check) > 0) {
            $msg = "<div class='alert alert-warning'>⚠️ Category already exists!</div>";
        } else {
            $query = "INSERT INTO categories (name) VALUES ('$category_name')";
            if (mysqli_query($conn, $query)) {
                $msg = "<div class='alert alert-success'>✅ Category added successfully!</div>";
            } else {
                $msg = "<div class='alert alert-danger'>❌ Error adding category!</div>";
            }
        }
    } else {
        $msg = "<div class='alert alert-danger'>⚠️ Please enter a category name.</div>";
    }
}

// DELETE CATEGORY
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $query = "DELETE FROM categories WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        $msg = "<div class='alert alert-success'>🗑️ Category deleted successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>❌ Error deleting category!</div>";
    }
}

// UPDATE CATEGORY
if (isset($_POST['update_category'])) {
    $id = intval($_POST['cat_id']);
    $name = mysqli_real_escape_string($conn, $_POST['cat_name']);
    $query = "UPDATE categories SET name='$name' WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        $msg = "<div class='alert alert-success'>✅ Category updated successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>❌ Error updating category!</div>";
    }
}

// Fetch all categories
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY id DESC");
?>

<?php include("includes/admin_header.php"); ?>

<div class="container my-4">
    <h2 class="fw-bold mb-4">Manage Categories</h2>

    <!-- Show messages -->
    <?php if (isset($msg)) echo $msg; ?>

    <!-- Add New Category Form -->
    <div class="card p-4 shadow-sm mb-4">
        <h5>Add New Category</h5>
        <form method="POST">
            <div class="input-group">
                <input type="text" name="category_name" class="form-control" placeholder="Enter category name" required>
                <button class="btn btn-primary" type="submit" name="add_category">Add</button>
            </div>
        </form>
    </div>

    <!-- Categories Table -->
    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white">
            <h5 class="m-0">Categories List</h5>
        </div>
        <div class="card-body">
            <table class="table table-striped table-hover text-center">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Category Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($categories) > 0): ?>
                        <?php while ($cat = mysqli_fetch_assoc($categories)): ?>
                            <tr>
                                <td><?= $cat['id'] ?></td>
                                <td><?= $cat['name'] ?></td>
                                <td>
                                    <!-- Edit Button (Modal Trigger) -->
                                    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $cat['id'] ?>">Edit</button>

                                    <!-- Delete Button -->
                                    <a href="?delete=<?= $cat['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
                                </td>
                            </tr>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="editModal<?= $cat['id'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-warning">
                                            <h5 class="modal-title">Edit Category</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="POST">
                                            <div class="modal-body">
                                                <input type="hidden" name="cat_id" value="<?= $cat['id'] ?>">
                                                <input type="text" name="cat_name" class="form-control" value="<?= $cat['name'] ?>" required>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" name="update_category" class="btn btn-success">Update</button>
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3">No categories found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include("includes/admin_footer.php"); ?>
