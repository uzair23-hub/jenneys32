<?php
session_start();
include("../includes/db.php");

// Redirect if admin not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Check if order ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: orders.php");
    exit();
}

$order_id = intval($_GET['id']);

// Fetch order info
$order_query = mysqli_query($conn, "
    SELECT orders.*, customers.name, customers.email, customers.address, customers.work_phone, customers.cell_phone, customers.dob,customers.category , customers.remarks 
    FROM orders 
    JOIN customers ON orders.id = customers.id 
    WHERE orders.id = $order_id
");

if (mysqli_num_rows($order_query) == 0) {
    echo "<div class='alert alert-danger'>Invalid order ID!</div>";
    exit();
}

$order = mysqli_fetch_assoc($order_query);

// Fetch ordered products
$products_query = mysqli_query($conn, "
    SELECT order_items.*, products.name AS product_name, products.price 
    FROM order_items 
    JOIN products ON order_items.product_id = products.id 
    WHERE order_items.order_id = $order_id
");

?>

<?php include("includes/admin_header.php"); ?>

<div class="container my-4">
    <h2 class="fw-bold mb-3">Order Details</h2>

    <!-- Order Info Card -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-dark text-white">
            <h5 class="m-0">Customer Information</h5>
        </div>
        <div class="card-body">
            <p><strong>Name:</strong> <?= $order['name'] ?></p>
            <p><strong>Email:</strong> <?= $order['email'] ?></p>
            <p><strong>Address:</strong> <?= $order['address'] ?></p>
            <p><strong>Phone:</strong> <?= $order['work_phone'] ?></p>
            <p><strong>Cell:</strong> <?= $order['cell_phone'] ?></p>
            <p><strong>Date of Birth:</strong> <?= $order['dob'] ?></p>
            <p><strong>Category:</strong> <?= $order['category'] ?></p>
            
            <p><strong>Remarks:</strong> <?= $order['remarks'] ?></p>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="m-0">Products Ordered</h5>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered text-center">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Product</th>
                        <th>Price (PKR)</th>
                        <th>Quantity</th>
                        <th>Subtotal (PKR)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 

                    $counter = 1;
                    $total = 0;
                     // Check if any products exist
                if (mysqli_num_rows($products_query) > 0) {
                    while ($product = mysqli_fetch_assoc($products_query)):
                        // Calculate subtotal per product
                        $subtotal = $product['price'] * $product['quantity'];
                        $total += $subtotal;
                ?>
                    
                        <tr>
                             <td><?php echo $counter++ ?></td>
                             <td><?php echo $product['product_name'] ?></td>
                            <td><?php echo number_format($product['price']) ?></td>
                            <td><?php echo $product['quantity'] ?></td>
                            <td><?php echo number_format($subtotal) ?></td>
                        </tr> 
                  
                    <?php
                    endwhile;
                } else {  ?>
                </tbody>
                <?php } ?>
                <tfoot>
                    <tr class="table-info">
                        <th colspan="4" class="text-end">Total Amount:</th>
                        <th>PKR <?php echo number_format($total) ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>


    <!-- Order Status -->
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h5 class="m-0">Order Status</h5>
        </div>
        <div class="card-body">
            <p><strong>Current Status:</strong> <span class="badge bg-primary"><?= $order['status'] ?></span></p>
            <p><strong>Order Date:</strong> <?= date("d M, Y", strtotime($order['order_date'])) ?></p>
            <a href="orders.php" class="btn btn-dark">← Back to Orders</a>
        </div>
    </div>
</div>

<?php include("includes/admin_footer.php"); ?>
