<?php
// Database connection settings
$host     = "localhost";   // Database host
$username = "root";        // Database username
$password = "";            // Database password
$database = "ecommerce";   // Database name

// Backup folder path
$backupFolder = __DIR__ . "/backups/";

// Create backups folder if not exists
if (!file_exists($backupFolder)) {
    mkdir($backupFolder, 0777, true);
}

// Set backup file name with timestamp
$backupFile = $backupFolder . $database . "_backup_" . date("Y-m-d_H-i-s") . ".sql";

// Run mysqldump command
$command = "C:\\xampp\\mysql\\bin\\mysqldump.exe --host=$host --user=$username --password=$password $database > \"$backupFile\"";

// Execute command
system($command, $result);
?>
<style>
  body {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background: #f8bbd0;
    font-family: 'Poppins', sans-serif;
  }
  .backup-result-card {
    background: #fff;
    border-radius: 18px;
    box-shadow: 0 8px 32px rgba(233, 30, 99, 0.12);
    padding: 32px 28px;
    max-width: 420px;
    width: 100%;
    text-align: center;
    margin: 40px auto;
    animation: fadeIn 0.8s ease;
    box-sizing: border-box;
  }
  .backup-result-card h3 {
    font-size: 1.5rem;
    margin-bottom: 12px;
    word-break: break-word;
  }
  .backup-result-card p {
    font-size: 1rem;
    color: black;
    margin-bottom: 18px;
    word-break: break-word;
  }
  .backup-result-card a {
    display: inline-block;
    margin-top: 10px;
    padding: 10px 22px;
    background-color: black;
    color: #fff;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    transition: background 0.3s;
    font-size: 1rem;
  }
  .backup-result-card a:hover {
    background-color: #302c2cff;
  }
  @keyframes fadeIn {
    0% { opacity: 0; transform: translateY(-20px); }
    100% { opacity: 1; transform: translateY(0); }
  }
  @media (max-width: 900px) {
    .backup-result-card {
      max-width: 95vw;
      padding: 24px 10px;
    }
    .backup-result-card h3 {
      font-size: 1.2rem;
    }
    .backup-result-card a {
      font-size: 0.95rem;
      padding: 8px 16px;
    }
  }
  @media (max-width: 600px) {
    .backup-result-card {
      padding: 14px 4px;
      border-radius: 10px;
      font-size: 0.95rem;
    }
    .backup-result-card h3 {
      font-size: 1rem;
    }
    .backup-result-card a {
      font-size: 0.9rem;
      padding: 6px 10px;
    }
  }
</style>
<?php include("includes/admin_header.php"); ?>
<div class="backup-result-card">
<?php
// Check if backup was successful
if ($result === 0) {
    echo "<h3 style='color:green;'>✅ Database backup completed successfully!</h3>";
    echo "<p>Backup saved at: <b>$backupFile</b></p>";
    echo '<a href="backup.php">⬅ Go Back</a>';
} else {
    echo "<h3 style='color:red;'>❌ Database backup failed!</h3>";
    echo "<p>Make sure mysqldump path is correct.</p>";
}
?>
</div>
<?php include("includes/admin_footer.php"); ?>